package com.infy.bookingservice;


import java.text.DateFormat;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {


	//static Logger logger = LogManager.getLogger(BookingService.class);

	@Autowired
	private BookingRepository bookingRepo;

	@Autowired
	private ShowRepository showRepo;

	public Booking addBooking(Booking booking) throws Exception {

		String sts="Booked";

		Integer showid = booking.getShowID().getShowId();
		Optional<Show> show = showRepo.findById(showid);

		Integer seatsbooked = booking.getSeatsBooked();
		if(show.get().getSeatAvailability()<seatsbooked) {

			throw new Exception("SEAT_UNAVAILABLE");
		}
		else
		{
			Integer seatsLeft = show.get().getSeatAvailability() - seatsbooked;
			show.get().setSeatAvailability(seatsLeft);
			Integer price = show.get().getRate();
			Integer amnt = booking.getSeatsBooked() * price;
			booking.setAmount(amnt);

			booking.setStatus(sts);


			return bookingRepo.save(booking);

		}
	}

	public List<Booking> getBookings() {
		return (List<Booking>) bookingRepo.findAll();
	}

	public Booking getBooking(Integer id) {
		return bookingRepo.findById(id).get();
	}

	public Booking deleteBookingbyId(Integer id) {
		String sts="Cancelled";

		Booking booking = getBooking(id);
		Show show = booking.getShowID();
		Integer remainingSeats = show.getSeatAvailability() + booking.getSeatsBooked();
		show.setSeatAvailability(remainingSeats);
		booking.setStatus(sts);
		return bookingRepo.save(booking);
		//bookingRepo.deleteById(id);
	}

	public List<Show> getAllShows() {
		return (List<Show>) showRepo.findAll();
	}

	public Show getShow(Integer id) {
		return showRepo.findById(id).get();
	}

	public Show addShow(Show show) {
		return showRepo.save(show);
	}

	public void deleteByShowId(Integer id) {
		showRepo.deleteById(id);

	}

	public Show updateShowDetails(Integer id, Show show) {
		show.setShowId(id);
		return showRepo.save(show);
	}


	public List<Show> findShowbyMovie(Integer movieId){
		List<Show> showList = new ArrayList<Show>();
		List<Show> allshows = getAllShows();
		for(Show show : allshows) {
			if(show.getMovieId().getMovieId().equals(movieId)) {
				showList.add(show);

			}
		}

		return showList;
	}

	public List<Show> findShowbyTheatre(Integer theatreId){
		List<Show> showList = new ArrayList<Show>();
		List<Show> allshows = getAllShows();
		for(Show show : allshows) {
			if(show.getTheatreId().getTheatreId().equals(theatreId)) {
				showList.add(show);

			}
		}

		return showList;
	}

//	public List<Booking> findBookingbyDate(String  fromDate, String  toDate) {
//		List<Booking> bookingList = new ArrayList<Booking>();
//		List<Booking> allBookings = getBookings();
//
//		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//		Date startdate = null;
//		Date enddate = null;
//
//		try {
//			startdate = dateFormat.parse(fromDate);
//			enddate = dateFormat.parse(toDate);
//		}
//		catch (ParseException e) {
//			e.printStackTrace();
//		}
//
//
//		for(Booking booking: allBookings ) {
//
//			if(booking.getShowID().getShowDate().equals(startdate)||
//					(booking.getShowID().getShowDate().after(startdate)&&
//							booking.getShowID().getShowDate().before(enddate))||
//					booking.getShowID().getShowDate().equals(enddate))
//
//				//			if(booking.getShowID().getShowDate().after(startdate)||booking.getShowID().getShowDate().before(enddate)||
//				//					booking.getShowID().getShowDate().equals(startdate)||booking.getShowID().getShowDate().equals(enddate))
//
//			{
//				bookingList.add(booking);
//			}
//
//		}
//
//		return bookingList;
//	}

}


