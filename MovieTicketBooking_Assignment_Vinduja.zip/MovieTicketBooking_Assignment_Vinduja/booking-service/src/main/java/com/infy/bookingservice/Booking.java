package com.infy.bookingservice;



import javax.persistence.Column;



import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;




@Entity
@Table(name = "booking_table")
public class Booking {

	@Id
	@Column(name ="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer bookingId;

	@OneToOne
	private User userName;

	@OneToOne
	private Show showID;


	private Integer seatsBooked;


	private Integer amount;
	
	private String status;


	public Booking() {
		super();

	}


	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}


	public User getUserName() {
		return userName;
	}


	public void setUserName(User userName) {
		this.userName = userName;
	}




	public Show getShowID() {
		return showID;
	}


	public void setShowID(Show showID) {
		this.showID = showID;
	}




	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	

}
