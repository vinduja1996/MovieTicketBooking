package com.UserService.userservice;


import java.util.ArrayList;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


@Service
public class UserServices {

	@Autowired
	private UserRepository repo;


	public List<User> getAllUser(){
		List<User> users= new ArrayList<>();
		repo.findAll().forEach(users::add);

		return users;

	}

	public User addUser(User user) {
		
		user.setRole("user");
		return repo.save(user);
	}

	public void deleteByUsername(String username) {

		repo.deleteById(username);     
	}



	public Optional<User> findUser(String id) {

		Optional<User> users = repo.findById(id);
		return users;
	}

	public User login (Login loginuser) throws Exception
	{
		User user=null;
		Optional <User> optuser=repo.findById(loginuser.getUserName());

		if(optuser.isPresent()) {
			user=optuser.get();
			if(user.getPassword().equals(loginuser.getPassword())) {
				return user;
			}

			else {
				 throw new Exception("Invalid Login");
			}
		}
		else {
            throw new Exception("Invalid Login");
		}
	}

	public User updateDetails(User user) {
		return repo.save(user);
	}

}