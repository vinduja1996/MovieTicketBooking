package com.UserService.userservice;


import java.util.List;
import java.util.Optional;


import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class UserServiceController {
    
    @Autowired
    private UserServices service;
     
        @GetMapping("/admin/getusers")  //works         
         public ResponseEntity<List<User>> getAllUsers(){
         return new ResponseEntity<>(service.getAllUser(),HttpStatus.OK);
        }
        
        @RequestMapping( method=RequestMethod.POST, value="/addusers") //works
        public ResponseEntity<User> addUser(@Valid @RequestBody User user){
            return new ResponseEntity<>(service.addUser(user), HttpStatus.OK);
        }
        
        @DeleteMapping(path = "/user/{username}") //works
        public ResponseEntity <Void> deleteUser(@PathVariable("username") String username){
        service.deleteByUsername(username);
        return new ResponseEntity<Void>(HttpStatus.OK);
            
        }
        @GetMapping(path = "/getuser/{username}") //works
        public ResponseEntity<Optional<User>> getMovieByMovieName(@PathVariable("username") String username){
            return new ResponseEntity<>(service.findUser(username),HttpStatus.OK);
            
        }
        
        @RequestMapping( method=RequestMethod.POST, value="/login") //works but user role problem
        public ResponseEntity<String> login(@Valid @RequestBody Login loginuser){
             return new ResponseEntity<>(service.login(loginuser), HttpStatus.OK);
             
            
        }
        
        @RequestMapping(method=RequestMethod.PUT, value="/updateuser/{username}") //works
        public ResponseEntity<User> updateDetails(@Valid @RequestBody User user){
            return new ResponseEntity<>(service.updateDetails(user), HttpStatus.OK);
        }
        

 

 

 

}