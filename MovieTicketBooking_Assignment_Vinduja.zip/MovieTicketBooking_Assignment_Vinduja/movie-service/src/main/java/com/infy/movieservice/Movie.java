package com.infy.movieservice;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "movie_table")
public class Movie {

	@Id
	@Column(name = "id")        	    
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer movieId;

	@NotNull
	private String movieName;

	@NotNull
	private String genre;

	private float rating;

	@NotNull
	private String language;

	public Movie(Integer movieId, String movieName, String genre, float rating, String language) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.genre = genre;
		this.rating = rating;
		this.language = language;
	}

	public Movie() {
		super();
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public float getRating() {
		return rating;
	}
	
	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	

}

