package com.infy.theatreservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TheatreService {
	
	@Autowired
	private TheatreRepository theatreRepo;
	
	public Theatre addTheatre(Theatre theatre) {
		return theatreRepo.save(theatre);
	}
	
	public List<Theatre> getTheatres(){
		return  (List<Theatre>) theatreRepo.findAll();
	}

	public Theatre getTheatre(Integer id){
		return theatreRepo.findById(id).get();
	}
	
	public List<Theatre> getTheatreBytheatreName(String theatreName){
		return (List<Theatre>) theatreRepo.findBytheatreName(theatreName);
	}
	
	public void deleteTheatrebyId(Integer id) {
		theatreRepo.deleteById(id);
	}
	
	public Theatre updateTheatreDetails(Integer id,  Theatre theatre) {
		theatre.setTheatreId(id);
		return theatreRepo.save(theatre);
	}
}
