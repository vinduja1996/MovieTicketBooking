package com.infy.theatreservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;



@Entity
@Table(name = "theatre_table")
public class Theatre {
	
	@Id
	@Column(name ="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer theatreId;
	
	@NotNull
	private String theatreName;
	
	@NotNull
	private String location;
	
	@NotNull
	private Integer capacity;
	
	public Theatre(Integer theatreId, String theatreName, String location, Integer capacity) {
		super();
		this.theatreId=theatreId;
		this.theatreName=theatreName;
		this.location=location;
		this.capacity=capacity;

	}
	
	public Theatre() {
		super();
	}

	


	public Integer getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Integer theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	
	
		
}
	
	
	
	
	
	


